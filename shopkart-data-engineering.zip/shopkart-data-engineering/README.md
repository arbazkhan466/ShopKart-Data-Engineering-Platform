# ShopKart Data Engineering Project

End-to-end e-commerce data platform using AWS, S3, Airflow, Databricks, PySpark, SQL, Data Warehouse and Power BI.

## Current phase
Phase 1 — Python + source data generation

## Run
```bash
pip install pandas numpy
python data_generator.py
```

Generated source files will appear under:
`data/raw/`
