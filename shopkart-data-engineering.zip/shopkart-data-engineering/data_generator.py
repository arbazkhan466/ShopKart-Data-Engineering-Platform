"""
ShopKart source data generator
Generates realistic e-commerce source data for the end-to-end
AWS + Airflow + Databricks + PySpark + SQL + DWH + Power BI project.
"""

from pathlib import Path
import random
from datetime import datetime, timedelta

import numpy as np
import pandas as pd

SEED = 42
random.seed(SEED)
np.random.seed(SEED)

BASE_DIR = Path(__file__).resolve().parent
RAW_DIR = BASE_DIR / "data" / "raw"
RAW_DIR.mkdir(parents=True, exist_ok=True)

N_CUSTOMERS = 10_000
N_PRODUCTS = 1_000
N_ORDERS = 100_000

FIRST_DATE = datetime(2026, 1, 1)
LAST_DATE = datetime(2026, 9, 14)

FIRST_NAMES = [
    "Arbaz", "Rahul", "Aisha", "Priya", "Aman", "Neha", "Vikram",
    "Sneha", "Rohan", "Kiran", "Ananya", "Aditya", "Isha", "Nikhil"
]
LAST_NAMES = [
    "Khan", "Sharma", "Patel", "Reddy", "Gupta", "Singh", "Verma",
    "Nair", "Iyer", "Das", "Mehta", "Joshi"
]

LOCATIONS = [
    ("Bengaluru", "Karnataka"),
    ("Mumbai", "Maharashtra"),
    ("Delhi", "Delhi"),
    ("Hyderabad", "Telangana"),
    ("Chennai", "Tamil Nadu"),
    ("Pune", "Maharashtra"),
    ("Kolkata", "West Bengal"),
    ("Ahmedabad", "Gujarat"),
]

CATEGORIES = {
    "Electronics": ["Mobiles", "Laptops", "Accessories"],
    "Home": ["Furniture", "Kitchen", "Decor"],
    "Fashion": ["Men", "Women", "Footwear"],
    "Beauty": ["Skincare", "Haircare", "Makeup"],
    "Sports": ["Fitness", "Outdoor", "Team Sports"],
}

PAYMENT_METHODS = ["UPI", "Credit Card", "Debit Card", "Net Banking", "COD"]
ORDER_STATUS = ["Delivered", "Shipped", "Processing", "Cancelled", "Returned"]


def random_date(start, end, n):
    seconds = int((end - start).total_seconds())
    offsets = np.random.randint(0, seconds + 1, n)
    return [start + timedelta(seconds=int(x)) for x in offsets]


def generate_customers():
    rows = []
    for i in range(1, N_CUSTOMERS + 1):
        first = random.choice(FIRST_NAMES)
        last = random.choice(LAST_NAMES)
        city, state = random.choice(LOCATIONS)
        signup = random_date(FIRST_DATE - timedelta(days=365), LAST_DATE, 1)[0]

        rows.append({
            "customer_id": f"C{i:05d}",
            "customer_name": f"{first} {last}",
            "email": f"{first.lower()}.{last.lower()}{i}@shopkart.com",
            "city": city,
            "state": state,
            "country": "India",
            "signup_date": signup.date(),
            "customer_segment": random.choices(
                ["Premium", "Standard", "Basic"],
                weights=[20, 55, 25],
                k=1
            )[0],
        })

    df = pd.DataFrame(rows)
    df.to_csv(RAW_DIR / "customers.csv", index=False)
    return df


def generate_products():
    rows = []
    product_id = 1

    for category, subcategories in CATEGORIES.items():
        for _ in range(N_PRODUCTS // len(CATEGORIES)):
            subcategory = random.choice(subcategories)
            price = round(random.uniform(200, 120_000), 2)
            cost = round(price * random.uniform(0.50, 0.85), 2)

            rows.append({
                "product_id": f"P{product_id:05d}",
                "product_name": f"{subcategory} Product {product_id:04d}",
                "category": category,
                "subcategory": subcategory,
                "price": price,
                "cost": cost,
            })
            product_id += 1

    df = pd.DataFrame(rows)
    df.to_csv(RAW_DIR / "products.csv", index=False)
    return df


def generate_orders(customers, products):
    customer_ids = customers["customer_id"].tolist()
    product_ids = products["product_id"].tolist()
    product_price = products.set_index("product_id")["price"].to_dict()

    order_dates = random_date(FIRST_DATE, LAST_DATE, N_ORDERS)
    rows = []

    for i in range(1, N_ORDERS + 1):
        product_id = random.choice(product_ids)
        quantity = random.choices([1, 2, 3, 4, 5], weights=[55, 25, 12, 6, 2], k=1)[0]
        discount = random.choice([0, 0.05, 0.10, 0.15, 0.20])

        rows.append({
            "order_id": f"O{i:07d}",
            "customer_id": random.choice(customer_ids),
            "product_id": product_id,
            "order_date": order_dates[i - 1],
            "quantity": quantity,
            "discount": discount,
            "order_status": random.choices(
                ORDER_STATUS,
                weights=[75, 10, 7, 4, 4],
                k=1
            )[0],
            "order_amount": round(
                product_price[product_id] * quantity * (1 - discount), 2
            ),
        })

    df = pd.DataFrame(rows)
    df.to_csv(RAW_DIR / "orders.csv", index=False)
    return df


def generate_payments(orders):
    rows = []

    for i, order in orders.reset_index(drop=True).iterrows():
        rows.append({
            "payment_id": f"PAY{i + 1:07d}",
            "order_id": order["order_id"],
            "payment_date": order["order_date"],
            "payment_method": random.choice(PAYMENT_METHODS),
            "payment_status": (
                "Failed"
                if order["order_status"] == "Cancelled"
                else random.choices(["Success", "Failed"], weights=[96, 4], k=1)[0]
            ),
            "amount": order["order_amount"],
        })

    df = pd.DataFrame(rows)
    df.to_csv(RAW_DIR / "payments.csv", index=False)
    return df


def add_controlled_data_quality_issues():
    """
    Adds small, intentional quality problems.
    These are useful later for the Data Quality phase.
    """
    customers_path = RAW_DIR / "customers.csv"
    orders_path = RAW_DIR / "orders.csv"

    customers = pd.read_csv(customers_path)
    orders = pd.read_csv(orders_path)

    # 10 duplicate customer records
    duplicates = customers.sample(10, random_state=SEED)
    customers = pd.concat([customers, duplicates], ignore_index=True)

    # 20 null customer IDs
    null_idx = orders.sample(20, random_state=SEED + 1).index
    orders.loc[null_idx, "customer_id"] = np.nan

    # 10 duplicate order records
    order_duplicates = orders.sample(10, random_state=SEED + 2)
    orders = pd.concat([orders, order_duplicates], ignore_index=True)

    customers.to_csv(customers_path, index=False)
    orders.to_csv(orders_path, index=False)


def main():
    print("Generating ShopKart datasets...")

    customers = generate_customers()
    products = generate_products()
    orders = generate_orders(customers, products)
    payments = generate_payments(orders)

    add_controlled_data_quality_issues()

    print("\nDone!")
    print(f"Output directory: {RAW_DIR}")
    print(f"Customers: {len(pd.read_csv(RAW_DIR / 'customers.csv')):,}")
    print(f"Products:  {len(pd.read_csv(RAW_DIR / 'products.csv')):,}")
    print(f"Orders:    {len(pd.read_csv(RAW_DIR / 'orders.csv')):,}")
    print(f"Payments:  {len(pd.read_csv(RAW_DIR / 'payments.csv')):,}")
    print("\nIntentional DQ issues added:")
    print("- Duplicate customers")
    print("- Null customer IDs in orders")
    print("- Duplicate orders")


if __name__ == "__main__":
    main()
